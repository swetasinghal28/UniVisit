
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;


public class WeatherAPIConnection {
	
	

	public static void main(String[] args) throws Exception {

		WeatherAPIConnection http = new WeatherAPIConnection();
		System.out.println("Program Started");
		http.sendGet();

	}

	// HTTP GET request
	private void sendGet() throws Exception {
		
		
		
		// Add all the data from text file to Arraylist
		
		ArrayList<String> list = new ArrayList<String>();
		try (BufferedReader br = new BufferedReader(new FileReader("csvFiles/CityList.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                list.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
		
		// Streamwriter for writing json response in text file.
		
		File fout = new File("csvFiles/WeatherData.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		
		
		
			
		// loop through all the data in list and prints json data
		
		for(int i = 0 ; i < list.size(); i++ )
		{
		
		StringBuilder urlbuilder = new StringBuilder("http://api.openweathermap.org/data/2.5/weather?q=");
		urlbuilder.append(list.get(i));
		urlbuilder.append(",us&mode=json&APPID=1b31aec5119c555c4443daa73b9b576d");
		
		String url = urlbuilder.toString();
	
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		// optional default is GET
		con.setRequestMethod("GET");
	
		BufferedReader in = new BufferedReader(
				new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		
		// Writing JSON Response in text file.
		
		String JSONString = response.toString();
		bw.write(JSONString + ",");
		bw.newLine();
		
	 }
		
		bw.close();
		
		System.out.println("Program Ended");

	}

}