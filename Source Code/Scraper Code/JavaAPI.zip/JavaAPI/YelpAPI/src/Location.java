

import java.util.List;

public class Location {
	private Coordinate coordinate;
	private List<String> display_address;
	private String city;
	
	public Coordinate getCoordinate() {
		return coordinate;
	}
	public void setCoordinate(Coordinate coordinate) {
		this.coordinate = coordinate;
	}
	
	public List<String> getDisplayAddress() {
		return display_address;
	}
	public void setDisplayAddress(List<String> displayAddress) {
		this.display_address = displayAddress;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
}
