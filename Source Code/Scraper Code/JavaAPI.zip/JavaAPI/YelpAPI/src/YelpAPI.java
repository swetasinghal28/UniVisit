import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import org.scribe.builder.ServiceBuilder;
import org.scribe.model.OAuthRequest;
import org.scribe.model.Response;
import org.scribe.model.Token;
import org.scribe.model.Verb;
import org.scribe.oauth.OAuthService;

import com.google.gson.Gson;


public class YelpAPI {

	public void start() throws Exception {
		  
		String CONSUMER_KEY = "4DjrfhszwTFBRZ5cR5cszg";
		String CONSUMER_SECRET = "TVOan2s8Z17vHH7AlIlWVM7pi_0";
		String TOKEN = "RdlHLnFOU8MTPsaXhvgOgOYN8dzZ39WA";
		String TOKEN_SECRET = "k_b_3jTuyjNrqZ9bRiucPl72m30";
		
		
		System.out.println("Program Started");
		
		// Saving all the CityList in ArrayList 
		ArrayList<String> list = new ArrayList<String>();
		try (BufferedReader br = new BufferedReader(new FileReader("csvFiles/CityList.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                list.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
		
		//Output file
		
		File fout = new File("csvFiles/FiveResturant.txt");
		FileOutputStream fos = new FileOutputStream(fout);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
		
		String category = "restaurants";
		String limit = "5";
		for(int i = 0; i < list.size(); i++)
		{
	 
		OAuthService service = new ServiceBuilder().provider(DefaultAPIExtension.class).apiKey(CONSUMER_KEY).apiSecret(CONSUMER_SECRET).build();
		Token accessToken = new Token(TOKEN, TOKEN_SECRET);
		OAuthRequest request = new OAuthRequest(Verb.GET, "http://api.yelp.com/v2/search");
		request.addQuerystringParameter("location", list.get(i));
		request.addQuerystringParameter("category", category);
		request.addQuerystringParameter("limit", limit);
		service.signRequest(accessToken, request);
		Response response = request.send();
		String rawData = response.getBody();
		
		
		
		
		 
		try {
			YelpSearchResult places = new Gson().fromJson(rawData, YelpSearchResult.class);

			for(Business biz : places.getBusinesses()) {
								
					bw.write(biz.getName() + ","  +  biz.getLocation().getCity() + "," + biz.getReviewCount() + "," + "\"" 
								+ biz.getPhone() + "\"" + "," + biz.getRating() + "," + "\"" + biz.getLocation().getDisplayAddress() 
									+ "\"" + "," + biz.getLocation().getCoordinate().getLatitude() + "," + biz.getLocation().getCoordinate().getLongitude() 
										+  "," + biz.getUrl());
					bw.newLine();
	
			}
			
			
		} catch(Exception e) {
			System.out.println("Error Parsing data");
			System.out.println(rawData);			
		}
		
		}
		
		bw.close();
		System.out.println("Program ended");
			
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		new YelpAPI().start();
	}

}
